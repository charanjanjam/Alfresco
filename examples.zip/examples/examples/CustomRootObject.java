package com.cts.examples;

import org.alfresco.repo.processor.BaseProcessorExtension;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CustomRootObject extends BaseProcessorExtension {
	private static Log logger = LogFactory.getLog(CustomRootObject.class);

	public void customMethod(String text) {
		if (logger.isDebugEnabled()) {
			logger.debug("CustomRootObject Method Executed--");
			logger.debug("CustomRootObject Method Test String--" + text);
		}
	}
}
