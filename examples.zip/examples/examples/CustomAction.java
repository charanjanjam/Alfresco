package com.cts.examples;

import java.util.List;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.action.executer.ActionExecuterAbstractBase;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ParameterDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CustomAction extends ActionExecuterAbstractBase{
	private static Log logger = LogFactory.getLog(CustomAction.class);

	 private ServiceRegistry serviceRegistry;

	    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
	        this.serviceRegistry = serviceRegistry;
	    }
	@Override
	protected void executeImpl(Action action, NodeRef actionedUponNodeRef) {
		 if (serviceRegistry.getNodeService().exists(actionedUponNodeRef) == true) {
			 String filename = (String) serviceRegistry.getNodeService().getProperty(
	                    actionedUponNodeRef, ContentModel.PROP_NAME);
			 if(logger.isDebugEnabled()){
				 logger.debug("Custom Action Executed on Node--"+actionedUponNodeRef);
				 logger.debug("Custom Action Executed on Node Name--"+filename);
			 }
			 
		 }
		
	}

	@Override
	protected void addParameterDefinitions(List<ParameterDefinition> arg0) {
		
		
	}

}
