package com.cts.examples;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.transaction.TransactionService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class CustomJob implements Job {
	private static Log logger = LogFactory.getLog(CustomJob.class);
	private ServiceRegistry serviceRegistry;
	private TransactionService transactionService;
	public void setServiceRegistry(final ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void setTransactionService(final TransactionService transactionService) {
		this.transactionService = transactionService;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void execute(final JobExecutionContext context) throws JobExecutionException {
		//Activate  DR JOB Transaction Trigger
				AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork() {
					public Object doWork() throws Exception {
						RetryingTransactionHelper.RetryingTransactionCallback<Object> txnWork = new RetryingTransactionHelper.RetryingTransactionCallback() {
							public Object execute() throws Exception {
								if(logger.isDebugEnabled()){
									 logger.debug("Custom JOB NextFireTime--"+context.getNextFireTime());
								 }
								return executJob();
							}
							
						};
						transactionService.getRetryingTransactionHelper().doInTransaction(txnWork, false);
						return null;
					}
				}, AuthenticationUtil.getAdminUserName());
		
	}
	public Object executJob(){
		if(logger.isDebugEnabled()){
			 logger.debug("Custom JOB Executed--");
		 }
		return null;
		
	}

}
